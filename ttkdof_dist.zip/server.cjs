var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_dotenv = __toESM(require("dotenv"), 1);
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_fs = __toESM(require("fs"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_app = require("firebase/app");
var import_firestore = require("firebase/firestore");
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "50mb" }));
var firebaseConfigPath = import_path.default.join(process.cwd(), "firebase-applet-config.json");
var firebaseConfig = {};
try {
  if (import_fs.default.existsSync(firebaseConfigPath)) {
    firebaseConfig = JSON.parse(import_fs.default.readFileSync(firebaseConfigPath, "utf8"));
  }
} catch (e) {
  console.warn("Could not load firebase-applet-config.json:", e);
}
var firebaseApp = null;
var db = null;
try {
  if (firebaseConfig && firebaseConfig.apiKey) {
    firebaseApp = (0, import_app.initializeApp)(firebaseConfig);
    db = (0, import_firestore.getFirestore)(firebaseApp, firebaseConfig.firestoreDatabaseId);
  }
} catch (e) {
  console.warn("Firebase initialization failed:", e);
}
function slugifyDepartment(dept) {
  if (!dept) return "kalite";
  const map = {
    "\xE7": "c",
    "\xC7": "C",
    "\u011F": "g",
    "\u011E": "G",
    "\u0131": "i",
    "I": "I",
    "\u0130": "i",
    "\xF6": "o",
    "\xD6": "O",
    "\u015F": "s",
    "\u015E": "S",
    "\xFC": "u",
    "\xDC": "U",
    " ": ""
  };
  let slug = dept.toLowerCase();
  for (let key in map) {
    slug = slug.replace(new RegExp(key, "g"), map[key]);
  }
  return slug;
}
function setupNotificationListener() {
  if (!db) {
    console.warn("[D\xD6F Notification Trigger] Firestore DB is not initialized. Listener skipped.");
    return;
  }
  console.log("Initializing server-side D\xD6F Notification Trigger Listener...");
  let isInitialLoad = true;
  (0, import_firestore.onSnapshot)((0, import_firestore.collection)(db, "dofs"), (snapshot) => {
    if (isInitialLoad) {
      isInitialLoad = false;
      console.log(`[D\xD6F Notification Trigger] Initial loading complete. Monitoring ${snapshot.size} records.`);
      return;
    }
    snapshot.docChanges().forEach(async (change) => {
      const dofData = change.doc.data();
      if (change.type === "added") {
        const { refNo, title, type, department, reporterName, description, proposedAction } = dofData;
        const deptSlug = slugifyDepartment(department);
        const departmentEmail = `${deptSlug}@sirket.com`;
        console.log(`
=============================================================`);
        console.log(`[TRIGGER: NEW D\xD6F SUBMITTED] Ref: ${refNo}`);
        console.log(`Birim: ${department} -> Al\u0131c\u0131: ${departmentEmail}`);
        console.log(`Konu: ${title}`);
        console.log(`-------------------------------------------------------------`);
        console.log(`A\xE7\u0131klama: ${description}`);
        console.log(`=============================================================
`);
        const htmlContent = `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #f1f5f9; border-radius: 12px; background-color: #ffffff;">
            <div style="border-bottom: 2px solid #6366f1; padding-bottom: 12px; margin-bottom: 20px;">
              <h2 style="color: #1e293b; margin: 0; font-size: 20px;">\u{1F6A8} Yeni D\xD6F Bildirimi Al\u0131nd\u0131</h2>
              <p style="color: #64748b; margin: 4px 0 0 0; font-size: 13px;">Sistem taraf\u0131ndan otomatik olarak olu\u015Fturulmu\u015Ftur (Sim\xFClat\xF6r).</p>
            </div>
            
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
              <tr style="background-color: #f8fafc;">
                <td style="padding: 10px; font-weight: bold; color: #475569; width: 150px; font-size: 13px;">D\xD6F Referans No:</td>
                <td style="padding: 10px; color: #1e293b; font-weight: bold; font-family: monospace; font-size: 14px; color: #4f46e5;">${refNo}</td>
              </tr>
              <tr>
                <td style="padding: 10px; font-weight: bold; color: #475569; font-size: 13px;">Faaliyet T\xFCr\xFC:</td>
                <td style="padding: 10px; color: #1e293b; text-transform: capitalize; font-size: 13px;">${type} Faaliyet</td>
              </tr>
              <tr style="background-color: #f8fafc;">
                <td style="padding: 10px; font-weight: bold; color: #475569; font-size: 13px;">\u0130lgili Birim / B\xF6l\xFCm:</td>
                <td style="padding: 10px; color: #1e293b; font-weight: bold; font-size: 13px;">${department}</td>
              </tr>
              <tr>
                <td style="padding: 10px; font-weight: bold; color: #475569; font-size: 13px;">Bildiren Personel:</td>
                <td style="padding: 10px; color: #1e293b; font-size: 13px;">${reporterName}</td>
              </tr>
              <tr style="background-color: #f8fafc;">
                <td style="padding: 10px; font-weight: bold; color: #475569; font-size: 13px;">Konu Ba\u015Fl\u0131\u011F\u0131:</td>
                <td style="padding: 10px; color: #1e293b; font-weight: bold; font-size: 13px;">${title}</td>
              </tr>
            </table>

            <div style="background-color: #fef2f2; border: 1px solid #fee2e2; border-radius: 8px; padding: 15px; margin-bottom: 15px;">
              <h4 style="color: #991b1b; margin: 0 0 8px 0; font-size: 13px; font-weight: bold;">Uygunsuzluk / Durum A\xE7\u0131klamas\u0131</h4>
              <p style="color: #374151; margin: 0; font-size: 13px; line-height: 1.5; white-space: pre-line;">${description}</p>
            </div>

            ${proposedAction ? `
            <div style="background-color: #eff6ff; border: 1px solid #dbeafe; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
              <h4 style="color: #1e40af; margin: 0 0 8px 0; font-size: 13px; font-weight: bold;">\xD6nerilen D\xFCzeltici Faaliyet</h4>
              <p style="color: #374151; margin: 0; font-size: 13px; line-height: 1.5; white-space: pre-line;">${proposedAction}</p>
            </div>
            ` : ""}

            <div style="background-color: #fafafa; border-radius: 8px; padding: 12px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.5;">
              Sisteminizde otomatik mail bildirim uzant\u0131s\u0131 kuruludur. E-posta ba\u015Far\u0131l\u0131 bir \u015Fekilde kuyru\u011Fa eklenmi\u015Ftir.
            </div>
          </div>
        `;
        try {
          await (0, import_firestore.addDoc)((0, import_firestore.collection)(db, "email_logs"), {
            to: departmentEmail,
            refNo,
            type: "yeni_dof",
            subject: `\u{1F6A8} [YEN\u0130 D\xD6F] ${refNo} - ${title}`,
            html: htmlContent,
            sentAt: (0, import_firestore.serverTimestamp)(),
            status: "sent"
          });
          console.log(`[D\xD6F Notification Logged in Firestore] for ${departmentEmail}`);
        } catch (e) {
          console.error("Failed to log notification in Firestore:", e);
        }
      } else if (change.type === "modified") {
        const { refNo, title, department, reporterName, reporterContact, status, adminFeedback } = dofData;
        console.log(`
=============================================================`);
        console.log(`[TRIGGER: D\xD6F UPDATED] Ref: ${refNo}`);
        console.log(`Yeni Durum: ${status}`);
        console.log(`Geri Bildirim: ${adminFeedback || "Girilmedi"}`);
        console.log(`=============================================================
`);
        const statusTranslations = {
          "yeni": "Yeni Bildirim",
          "inceleniyor": "\u0130nceleme A\u015Famas\u0131nda",
          "cozuldu": "Tamamland\u0131 / \xC7\xF6z\xFCld\xFC",
          "reddedildi": "Reddedildi"
        };
        const statusColors = {
          "yeni": "#3b82f6",
          "inceleniyor": "#f59e0b",
          "cozuldu": "#10b981",
          "reddedildi": "#ef4444"
        };
        const htmlContent = `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #f1f5f9; border-radius: 12px; background-color: #ffffff;">
            <div style="border-bottom: 2px solid ${statusColors[status] || "#6366f1"}; padding-bottom: 12px; margin-bottom: 20px;">
              <h2 style="color: #1e293b; margin: 0; font-size: 20px;">\u{1F504} D\xD6F Durumu G\xFCncellendi</h2>
              <p style="color: #64748b; margin: 4px 0 0 0; font-size: 13px;">D\xD6F takip sistemimiz taraf\u0131ndan otomatik g\xFCncellenmi\u015Ftir.</p>
            </div>
            
            <p style="color: #334155; font-size: 14px; line-height: 1.5;">
              Say\u0131n <strong>${reporterName}</strong>, bildirmi\u015F oldu\u011Funuz uygunsuzluk kayd\u0131 g\xFCncellenmi\u015Ftir.
            </p>

            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
              <tr style="background-color: #f8fafc;">
                <td style="padding: 10px; font-weight: bold; color: #475569; width: 150px; font-size: 13px;">D\xD6F Referans No:</td>
                <td style="padding: 10px; color: #1e293b; font-weight: bold; font-family: monospace; font-size: 14px; color: #4f46e5;">${refNo}</td>
              </tr>
              <tr>
                <td style="padding: 10px; font-weight: bold; color: #475569; font-size: 13px;">Konu Ba\u015Fl\u0131\u011F\u0131:</td>
                <td style="padding: 10px; color: #1e293b; font-weight: bold; font-size: 13px;">${title}</td>
              </tr>
              <tr style="background-color: #f8fafc;">
                <td style="padding: 10px; font-weight: bold; color: #475569; font-size: 13px;">Yeni Durum:</td>
                <td style="padding: 10px; font-size: 13px;">
                  <span style="display: inline-block; background-color: ${statusColors[status] || "#cbd5e1"}15; color: ${statusColors[status] || "#64748b"}; border: 1px solid ${statusColors[status] || "#cbd5e1"}; font-weight: bold; padding: 4px 10px; border-radius: 20px; font-size: 11px; text-transform: uppercase;">
                    ${statusTranslations[status] || status}
                  </span>
                </td>
              </tr>
            </table>

            ${adminFeedback ? `
            <div style="background-color: #f8fafc; border-left: 4px solid #6366f1; border-radius: 4px; padding: 15px; margin-bottom: 20px;">
              <h4 style="color: #1e293b; margin: 0 0 6px 0; font-size: 13px; font-weight: bold;">Y\xF6netici / \u0130nceleme Geri Bildirimi</h4>
              <p style="color: #475569; margin: 0; font-size: 13px; line-height: 1.5; white-space: pre-line;">${adminFeedback}</p>
            </div>
            ` : ""}

            <div style="background-color: #fafafa; border-radius: 8px; padding: 12px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.5;">
              D\xD6F kayd\u0131n\u0131z\u0131n son durumunu canl\u0131 takip etmek i\xE7in sisteme giri\u015F yap\u0131p <strong>${refNo}</strong> referans numaras\u0131 ile arama yapabilirsiniz.
            </div>
          </div>
        `;
        try {
          const emailTargets = [];
          if (reporterContact && reporterContact.includes("@")) {
            emailTargets.push(reporterContact.trim());
          }
          const deptSlug = slugifyDepartment(department);
          emailTargets.push(`${deptSlug}@sirket.com`);
          for (const targetEmail of emailTargets) {
            await (0, import_firestore.addDoc)((0, import_firestore.collection)(db, "email_logs"), {
              to: targetEmail,
              refNo,
              type: "durum_guncelleme",
              subject: `\u{1F504} [D\xD6F DURUM G\xDCNCELLEME] ${refNo} - Yeni Durum: ${statusTranslations[status] || status}`,
              html: htmlContent,
              sentAt: (0, import_firestore.serverTimestamp)(),
              status: "sent"
            });
            console.log(`[D\xD6F Update Logged in Firestore] for ${targetEmail}`);
          }
        } catch (e) {
          console.error("Failed to log update notification in Firestore:", e);
        }
      }
    });
  });
}
var aiClient = null;
function getGeminiClient() {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn("GEMINI_API_KEY is not defined. AI features will be unavailable.");
    }
    aiClient = new import_genai.GoogleGenAI({
      apiKey: key || "",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
});
app.post("/api/analyze-dof", async (req, res) => {
  const { title, type, department, description, proposedAction } = req.body;
  if (!title || !type || !description) {
    return res.status(400).json({ error: "Eksik bilgi: Ba\u015Fl\u0131k, tip ve a\xE7\u0131klama zorunludur." });
  }
  try {
    const ai = getGeminiClient();
    if (!process.env.GEMINI_API_KEY) {
      throw new Error("Gemini API key is not configured on the server.");
    }
    const prompt = `
A\u015Fa\u011F\u0131da bir kullan\u0131c\u0131n\u0131n bildirdi\u011Fi D\xFCzeltici \xD6nleyici Faaliyet (DOF) formuna ait detaylar yer almaktad\u0131r.
L\xFCtfen bu uygunsuzluk durumunu profesyonel bir Kalite Y\xF6netim Temsilcisi (QMR) olarak analiz et.

[DOF Detaylar\u0131]
- Konu / Ba\u015Fl\u0131k: ${title}
- Faaliyet T\xFCr\xFC: ${type}
- \u0130lgili B\xF6l\xFCm: ${department || "Belirtilmemi\u015F"}
- Durum / Uygunsuzluk A\xE7\u0131klamas\u0131: ${description}
- \xD6nerilen \xC7\xF6z\xFCm / Faaliyet: ${proposedAction || "Belirtilmemi\u015F"}

Senden beklenenler:
1. Risk Seviyesi Analizi: Bu durumun kurum/s\xFCre\xE7 i\xE7in olu\u015Fturdu\u011Fu risk seviyesini (D\xFC\u015F\xFCk, Orta, Y\xFCksek) belirle ve k\u0131saca nedenini a\xE7\u0131kla.
2. Faaliyet Plan\u0131 De\u011Ferlendirmesi: Kullan\u0131c\u0131n\u0131n \xF6nerdi\u011Fi faaliyeti de\u011Ferlendir. Varsa eksikleri tamamlayan, ISO 9001 standartlar\u0131na uygun, somut ve takip edilebilir 3 ad\u0131ml\u0131 bir "Aksiyon/D\xFCzeltme Plan\u0131" \xF6ner.
3. Geri Bildirim Yan\u0131t Tasla\u011F\u0131: Formu bildiren ki\u015Fiye hitaben yaz\u0131lm\u0131\u015F; te\u015Fekk\xFCr eden, konunun incelendi\u011Fini belirten ve sonraki ad\u0131mlar\u0131 a\xE7\u0131klayan nazik, profesyonel bir T\xFCrk\xE7e e-posta/mesaj tasla\u011F\u0131 olu\u015Ftur.

L\xFCtfen yan\u0131t\u0131 kesinlikle ge\xE7erli bir JSON format\u0131nda d\xF6nd\xFCr. JSON yap\u0131s\u0131 tam olarak \u015Fu \u015Fekilde olmal\u0131d\u0131r ve ba\u015Fka hi\xE7bir metin veya markdown sarmalay\u0131c\u0131s\u0131 (\`\`\`json vs.) i\xE7ermemelidir:
{
  "riskLevel": "D\xFC\u015F\xFCk" | "Orta" | "Y\xFCksek",
  "riskReason": "Risk seviyesinin gerek\xE7esi...",
  "actionSuggestions": [
    "Aksiyon 1...",
    "Aksiyon 2...",
    "Aksiyon 3..."
  ],
  "feedbackDraft": "Merhaba Say\u0131n [\u0130sim]..."
}
`;
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });
    const responseText = response.text;
    if (!responseText) {
      throw new Error("Gemini returned an empty response.");
    }
    const analysisResult = JSON.parse(responseText);
    res.json(analysisResult);
  } catch (error) {
    console.error("Gemini analysis error:", error);
    res.status(500).json({
      error: "AI Analizi s\u0131ras\u0131nda bir hata olu\u015Ftu.",
      details: error.message || error,
      fallback: {
        riskLevel: "Orta",
        riskReason: "Yapay zeka analizi \u015Fu anda kullan\u0131lam\u0131yor. L\xFCtfen formu manuel de\u011Ferlendiriniz.",
        actionSuggestions: [
          "Uygunsuzlu\u011Fun k\xF6k nedenini ara\u015Ft\u0131r\u0131n.",
          "Ge\xE7ici bir d\xFCzeltici faaliyet uygulay\u0131n.",
          "Faaliyetin etkinli\u011Fini 30 g\xFCn sonra kontrol edin."
        ],
        feedbackDraft: "Bildiriminiz i\xE7in te\u015Fekk\xFCr ederiz. Kalite y\xF6netim ekibimiz konuyu en k\u0131sa s\xFCrede inceleyecektir."
      }
    });
  }
});
app.get("/api/download-dist-zip", (req, res) => {
  const zipPath = import_path.default.join(process.cwd(), "ttkdof_dist.zip");
  if (import_fs.default.existsSync(zipPath)) {
    res.setHeader("Content-Disposition", "attachment; filename=ttkdof-production-dist.zip");
    res.setHeader("Content-Type", "application/zip");
    res.sendFile(zipPath);
  } else {
    res.status(404).send("Zip file not found");
  }
});
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Vite dev server middleware...");
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving static production build...");
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
    setupNotificationListener();
  });
}
setupViteOrStatic().catch((err) => {
  console.error("Failed to start server:", err);
});
//# sourceMappingURL=server.cjs.map
